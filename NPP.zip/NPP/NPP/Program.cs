﻿namespace NPP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Eromu> plants = Eromu.LoadFromTXT();

            Eromu First = plants.MinBy(x => x.Built)!;

            Console.WriteLine($"4.Feladat: Az első erőművet {First.CountryName} állította üzembe, {DateTime.Today.Year - First.Built} évvel ezelőtt\n");

            // Statisztika, azokról az országról, ahol legalább 3 erőmű van

            var stat = plants.GroupBy(p => p.CountryName)
                             .Select(g => new
                             {
                                 Country = g.Key,
                                 Count = g.Count(),
                                 SumPerformance = g.Sum(p => p.Performance)
                             })
                             .Where(s => s.Count > 2)
                             .ToList();

            Console.WriteLine("5.Feladat: Statisztika");

            stat.ForEach(s => Console.WriteLine($"\t {s.Country} - {s.Count} db (Össz: {s.SumPerformance} MW)"));

            Console.WriteLine($"6.Feladat: A 2000 utáni ... {AtlagSzamol(plants):f2} MW");
        }

        static double AtlagSzamol(List<Eromu> plants)
        {
            var before = plants.Where(p => p.Built < 2000).Average(p => p.Performance);
            var after = plants.Where(p => p.Built >= 2000).Average(p => p.Performance);
            return after - before;
        }
    }
}
