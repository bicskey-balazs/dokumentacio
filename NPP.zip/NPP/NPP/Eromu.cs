﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPP
{
    public class Eromu
    {
        public string CountryCode { get; set; } = "";
        public string CountryName { get; set; } = "";
        public string Name { get; set; } = "";
        public int Performance { get; set; }
        public int Built { get; set; }


        public Eromu(string row)
        {
            var data = row.Split(';');
            CountryCode = data[0];
            CountryName = data[1];
            Name = data[2];
            Performance = int.Parse(data[3]);
            Built = int.Parse(data[4]);
        }

        public static List<Eromu> LoadFromTXT(string FileName = "npp.txt")
        {
            return File.ReadAllLines(FileName)
                       .Skip(1)
                       .Select(x => new Eromu(x))
                       .ToList();
        }
    }
}
