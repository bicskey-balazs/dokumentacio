﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NPPGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCalc_Click(object sender, RoutedEventArgs e)
        {
            LblGW.Content = "0,00 GW"; 
            if (!int.TryParse(TxtFrom.Text, out int from))
            {
                MessageBox.Show("Hibás Évszám...");
                return;
            }
            if (!int.TryParse(TxtTo.Text, out int to))
            {
                MessageBox.Show("Hibás Évszám...");
                return;
            }
            if (from > to)
            {
                MessageBox.Show("Hibás Évszám...");
                return;
            }
            if (!double.TryParse(TxtMW.Text, out double mw))
            {
                MessageBox.Show("A teljesítmény csak törtszám lehet!");
                return;
            }

            LblGW.Content = $"{(to-from) * 365 * mw / 1000:f2} GW";

        }
    }
}